package br.uema.aulanet.model;

public enum StatusParcela {
    PENDENTE, PAGO, ATRASADO
}
