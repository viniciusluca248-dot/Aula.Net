package br.uema.aulanet.model;

public enum StatusAgendamento {
    SOLICITADO, CONFIRMADO, CANCELADO, CONCLUIDO
}
