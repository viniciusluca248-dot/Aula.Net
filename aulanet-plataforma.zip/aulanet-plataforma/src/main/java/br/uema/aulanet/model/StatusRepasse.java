package br.uema.aulanet.model;

public enum StatusRepasse {
    PENDENTE, REALIZADO
}
