package br.uema.aulanet.model;

public enum TipoPagamento {
    A_VISTA, PARCELADO
}
