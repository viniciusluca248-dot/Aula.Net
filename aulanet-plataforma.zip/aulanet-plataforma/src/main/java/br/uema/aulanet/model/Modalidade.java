package br.uema.aulanet.model;

public enum Modalidade {
    PRESENCIAL, ONLINE
}
