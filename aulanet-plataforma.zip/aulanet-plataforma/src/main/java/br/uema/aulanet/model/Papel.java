package br.uema.aulanet.model;

public enum Papel {
    ALUNO, PROFESSOR, ADMIN
}
