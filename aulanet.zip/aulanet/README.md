# Aula.net - TCC UEMA

Plataforma de agendamento de aulas particulares (Spring Boot 3.3 + Java 17).

## Como rodar (3 passos)

1. **Abra o `pom.xml` no IntelliJ** (File -> Open -> selecione o pom.xml -> Open as Project).
2. Aguarde o Maven baixar as dependencias.
3. Rode `AulanetApplication.java` (botao verde Run).

Acesse: <http://localhost:8080>

> Banco H2 em memoria ja vem configurado. **NAO precisa instalar MySQL nem Lombok.**

## Usuarios de teste (senha: `123456`)

| E-mail | Papel |
|---|---|
| admin@aulanet.com | ADMINISTRADOR |
| aluno@aulanet.com | ALUNO |
| prof@aulanet.com  | PROFESSOR |

## Console do banco H2

<http://localhost:8080/h2-console>
- JDBC URL: `jdbc:h2:mem:aulanet`
- User: `sa` (senha em branco)

## Trocar para MySQL

No `application.properties`, comente o bloco H2 e descomente o bloco MySQL.
Ajuste usuario/senha. O banco `aulanet` sera criado automaticamente.

## Endpoints principais

| Metodo | URL | Descricao |
|---|---|---|
| POST | `/api/auth/register` | cria usuario (`{nome,email,senha,role}`) |
| POST | `/api/auth/login`    | retorna token JWT |
| GET  | `/api/disciplinas`   | lista disciplinas |
| POST | `/api/disciplinas`   | cria (precisa token) |
| GET  | `/api/usuarios/professores` | lista professores |
| GET  | `/api/agendamentos`  | lista agendamentos |
| POST | `/api/agendamentos`  | cria agendamento |

Envie o token nos endpoints protegidos: `Authorization: Bearer <token>`.

## Estrutura

```
src/main/java/br/uema/aulanet/
  AulanetApplication.java
  config/SecurityConfig.java
  controller/   (Auth, Disciplina, Usuario, Agendamento)
  dto/          (Login, Register, AuthResponse)
  model/        (Usuario, Disciplina, Agendamento, Role)
  repository/   (3 interfaces JPA)
  security/     (JwtUtil, JwtFilter)
src/main/resources/
  application.properties
  data.sql
  static/       (HTML/CSS/JS)
```

## Problemas comuns

- **Porta 8080 em uso** -> mude `server.port` no `application.properties`.
- **JDK errado** -> Project Structure -> SDK = 17.
- **Maven nao baixa** -> File -> Invalidate Caches / Reload Maven Project.
