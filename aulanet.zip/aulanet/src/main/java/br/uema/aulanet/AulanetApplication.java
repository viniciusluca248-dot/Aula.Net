package br.uema.aulanet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AulanetApplication {
    public static void main(String[] args) {
        SpringApplication.run(AulanetApplication.class, args);
    }
}
