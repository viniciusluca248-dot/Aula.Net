package br.uema.aulanet.repository;

import br.uema.aulanet.model.Disciplina;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DisciplinaRepository extends JpaRepository<Disciplina, Long> {}
