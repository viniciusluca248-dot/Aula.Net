package br.uema.aulanet.model;

public enum Role {
    ALUNO, PROFESSOR, ADMINISTRADOR
}
