package br.uema.aulanet.controller;

import br.uema.aulanet.model.Role;
import br.uema.aulanet.model.Usuario;
import br.uema.aulanet.repository.UsuarioRepository;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/usuarios")
public class UsuarioController {

    private final UsuarioRepository repo;
    public UsuarioController(UsuarioRepository repo) { this.repo = repo; }

    @GetMapping
    public List<Usuario> listar() { return repo.findAll(); }

    @GetMapping("/professores")
    public List<Usuario> professores() { return repo.findByRole(Role.PROFESSOR); }

    @GetMapping("/alunos")
    public List<Usuario> alunos() { return repo.findByRole(Role.ALUNO); }
}
