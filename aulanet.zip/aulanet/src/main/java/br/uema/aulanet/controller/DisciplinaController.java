package br.uema.aulanet.controller;

import br.uema.aulanet.model.Disciplina;
import br.uema.aulanet.repository.DisciplinaRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/disciplinas")
public class DisciplinaController {

    private final DisciplinaRepository repo;
    public DisciplinaController(DisciplinaRepository repo) { this.repo = repo; }

    @GetMapping
    public List<Disciplina> listar() { return repo.findAll(); }

    @GetMapping("/{id}")
    public ResponseEntity<Disciplina> buscar(@PathVariable Long id) {
        return repo.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Disciplina criar(@RequestBody Disciplina d) { return repo.save(d); }

    @PutMapping("/{id}")
    public ResponseEntity<Disciplina> atualizar(@PathVariable Long id, @RequestBody Disciplina d) {
        return repo.findById(id).map(rec -> {
            rec.setNome(d.getNome());
            rec.setDescricao(d.getDescricao());
            return ResponseEntity.ok(repo.save(rec));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> remover(@PathVariable Long id) {
        return repo.findById(id).map(rec -> { repo.deleteById(id); return ResponseEntity.ok().build(); })
                .orElse(ResponseEntity.notFound().build());
    }
}
