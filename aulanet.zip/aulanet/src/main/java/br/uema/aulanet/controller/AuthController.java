package br.uema.aulanet.controller;

import br.uema.aulanet.dto.AuthResponse;
import br.uema.aulanet.dto.LoginRequest;
import br.uema.aulanet.dto.RegisterRequest;
import br.uema.aulanet.model.Role;
import br.uema.aulanet.model.Usuario;
import br.uema.aulanet.repository.UsuarioRepository;
import br.uema.aulanet.security.JwtUtil;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final UsuarioRepository repo;
    private final PasswordEncoder encoder;
    private final JwtUtil jwt;

    public AuthController(UsuarioRepository repo, PasswordEncoder encoder, JwtUtil jwt) {
        this.repo = repo; this.encoder = encoder; this.jwt = jwt;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequest req) {
        if (repo.existsByEmail(req.getEmail()))
            return ResponseEntity.badRequest().body(Map.of("erro", "E-mail ja cadastrado"));
        Role role;
        try { role = Role.valueOf(req.getRole()); }
        catch (Exception e) { return ResponseEntity.badRequest().body(Map.of("erro", "Role invalida")); }

        Usuario u = new Usuario(req.getNome(), req.getEmail(), encoder.encode(req.getSenha()), role);
        repo.save(u);
        String token = jwt.gerarToken(u.getEmail(), u.getRole().name());
        return ResponseEntity.ok(new AuthResponse(token, u.getNome(), u.getEmail(), u.getRole().name()));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest req) {
        return repo.findByEmail(req.getEmail())
            .filter(u -> encoder.matches(req.getSenha(), u.getSenha()))
            .<ResponseEntity<?>>map(u -> ResponseEntity.ok(new AuthResponse(
                jwt.gerarToken(u.getEmail(), u.getRole().name()),
                u.getNome(), u.getEmail(), u.getRole().name())))
            .orElse(ResponseEntity.status(401).body(Map.of("erro", "Credenciais invalidas")));
    }
}
