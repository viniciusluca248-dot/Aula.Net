package br.uema.aulanet.dto;

public class RegisterRequest {
    private String nome;
    private String email;
    private String senha;
    private String role; // ALUNO ou PROFESSOR
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getSenha() { return senha; }
    public void setSenha(String senha) { this.senha = senha; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
}
