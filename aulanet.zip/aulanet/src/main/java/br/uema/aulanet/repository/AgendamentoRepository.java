package br.uema.aulanet.repository;

import br.uema.aulanet.model.Agendamento;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface AgendamentoRepository extends JpaRepository<Agendamento, Long> {
    List<Agendamento> findByAlunoId(Long alunoId);
    List<Agendamento> findByProfessorId(Long professorId);
}
