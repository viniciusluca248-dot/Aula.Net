package br.uema.aulanet.controller;

import br.uema.aulanet.model.Agendamento;
import br.uema.aulanet.repository.AgendamentoRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/agendamentos")
public class AgendamentoController {

    private final AgendamentoRepository repo;
    public AgendamentoController(AgendamentoRepository repo) { this.repo = repo; }

    @GetMapping
    public List<Agendamento> listar() { return repo.findAll(); }

    @GetMapping("/aluno/{id}")
    public List<Agendamento> porAluno(@PathVariable Long id) { return repo.findByAlunoId(id); }

    @GetMapping("/professor/{id}")
    public List<Agendamento> porProfessor(@PathVariable Long id) { return repo.findByProfessorId(id); }

    @PostMapping
    public Agendamento criar(@RequestBody Agendamento a) { return repo.save(a); }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> remover(@PathVariable Long id) {
        if (!repo.existsById(id)) return ResponseEntity.notFound().build();
        repo.deleteById(id);
        return ResponseEntity.ok().build();
    }
}
