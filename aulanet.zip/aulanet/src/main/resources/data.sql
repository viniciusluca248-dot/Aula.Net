-- Senha padrao para todos: "123456" (BCrypt)
MERGE INTO usuarios (id, nome, email, senha, role) KEY(id) VALUES
 (1, 'Admin',      'admin@aulanet.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'ADMINISTRADOR'),
 (2, 'Joao Aluno', 'aluno@aulanet.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'ALUNO'),
 (3, 'Maria Prof', 'prof@aulanet.com',  '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'PROFESSOR');

MERGE INTO disciplinas (id, nome, descricao) KEY(id) VALUES
 (1, 'Matematica',  'Algebra, calculo e geometria'),
 (2, 'Portugues',   'Gramatica e redacao'),
 (3, 'Programacao', 'Java e logica');
