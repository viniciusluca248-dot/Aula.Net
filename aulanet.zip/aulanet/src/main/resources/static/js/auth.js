async function api(url, method='GET', body=null){
  const u = JSON.parse(localStorage.getItem('aulanet') || 'null');
  const headers = {'Content-Type':'application/json'};
  if(u && u.token) headers['Authorization'] = 'Bearer ' + u.token;
  const opts = { method, headers };
  if(body) opts.body = JSON.stringify(body);
  return fetch(url, opts);
}
